﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double lado1, lado2, lado3;

        public Form1()
        {
            InitializeComponent();
        }





        


 




        private void btnLimpar_Click(object sender, EventArgs e)
            {
                txtLado1.Clear();
                txtLado2.Clear();
                txtLado3.Clear();
                txtTriangulo.Clear();
                txtLado1.Focus();
            }

        private void btnCalcular_Click_1(object sender, EventArgs e)
        {
            
                if (lado1 > 0 && lado2 > 0 && lado3 > 0 &&
        (lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1))
                {
                    if (lado1 == lado2 && lado2 == lado3)
                    {
                        txtTriangulo.Text = "Triângulo Equilátero";
                    }
                    else if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3)
                    {
                        txtTriangulo.Text = "Triângulo Escaleno";
                    }
                    else
                    {
                        txtTriangulo.Text = "Triângulo Isósceles";
                    }
                }
                else
                {
                    MessageBox.Show("Não é um triângulo válido.");
                
            }
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out lado1) || (lado1 <= 0))
            {
                MessageBox.Show("Valor invalido para um triangulo");
                txtLado1.Focus();

            }
            else
                txtLado2.Focus();

        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado2.Text, out lado2) || (lado2 <= 0))
            {
                MessageBox.Show("Valor invalido para um triangulo");
                txtLado2.Focus();
            }
            else
                txtLado3.Focus();
        
    }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado3.Text, out lado3) || (lado3 <= 0))
            {
                MessageBox.Show("Valor invalido para um triangulo");
                txtLado3.Focus();
            }
        }

        private void btnSair_Click_1(object sender, EventArgs e)
        
        {
            Close();
        }

        private void txtTriangulo_TextChanged(object sender, EventArgs e)
        {

        }

    }
}