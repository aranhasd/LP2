﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class Form1 : Form
    {
        double salarioLiquido, salarioBruto, descontoINSS, descontoIRPF, numFilhos, valorSalarioFamilia;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (salarioBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                descontoINSS = ((7.65 / 100) * salarioBruto);
                txtDescontoINSS.Text = descontoINSS.ToString();
            }
            else if (salarioBruto <= 1050)
            {
                txtAliquotaINSS.Text = "8,65%";
                descontoINSS = ((8.65 / 100) * salarioBruto);
                txtDescontoINSS.Text = descontoINSS.ToString();
            }
            else if (salarioBruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9.00%";
                descontoINSS = ((9.00 / 100) * salarioBruto);
                txtDescontoINSS.Text = descontoINSS.ToString();
            }
            else if (salarioBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11.0%";
                descontoINSS = ((11.0 / 100) * salarioBruto);
                txtDescontoINSS.Text = descontoINSS.ToString();
            }
            else if (salarioBruto > 2801)
            {
                txtAliquotaINSS.Text = "Teto";
                descontoINSS = (salarioBruto - 308.17);
                txtDescontoINSS.Text = descontoINSS.ToString();
            }

            if (salarioBruto <= 1257.12)
            {
                txtAliquotaIRPF.Text = "Isento";
                descontoIRPF = 0;
                txtDescontoIRPF.Text = descontoIRPF.ToString();
            }
            else if (salarioBruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15%";
                descontoIRPF = ((15.0 / 100) * salarioBruto);
                txtDescontoIRPF.Text = descontoIRPF.ToString();
            }
            else if (salarioBruto > 2512.08)
            {
                txtAliquotaIRPF.Text = "27.5%";
                descontoIRPF = ((27.5 / 100) * salarioBruto);
                txtDescontoIRPF.Text = descontoIRPF.ToString();
               
            }
            if (salarioBruto <= 435.52)
            {
                numFilhos = (int)numupDFilhos.Value;
                valorSalarioFamilia = salarioBruto + (numFilhos * 22.33);
                txtSalarioFamilia.Text = valorSalarioFamilia.ToString();
            }
            else if (salarioBruto <= 654.61)
            {
                numFilhos = (int)numupDFilhos.Value;
                valorSalarioFamilia = salarioBruto + (numFilhos * 15.74);
                txtSalarioFamilia.Text = valorSalarioFamilia.ToString();
            }
            else if (salarioBruto > 654.61)
            {
                numFilhos = (int)numupDFilhos.Value;
                valorSalarioFamilia = 0;
                txtSalarioFamilia.Text = valorSalarioFamilia.ToString();
            }


            salarioLiquido = (salarioBruto + valorSalarioFamilia - descontoIRPF - descontoINSS);
            txtSalarioLiquido.Text = salarioLiquido.ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNomeFuncionario_Validated(object sender, EventArgs e)
        {
            if (txtNomeFuncionario.Text == "") 
            {
                MessageBox.Show("Insira um nome.");
                txtNomeFuncionario.Focus();
            }
        }

        private void mskSalarioBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskSalarioBruto.Text, out salarioBruto) || (salarioBruto <= 0))
                MessageBox.Show("Insira um salário válido");
            mskSalarioBruto.Focus();
        }
    }
        
}
