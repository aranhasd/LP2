﻿namespace PMetodos
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exercícioF1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercícioF2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercícioF3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioF4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercícioF5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fSairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editorDeTextosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercícioF1ToolStripMenuItem,
            this.exercícioF2ToolStripMenuItem,
            this.exercícioF3ToolStripMenuItem,
            this.exercicioF4ToolStripMenuItem,
            this.exercícioF5ToolStripMenuItem,
            this.fSairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exercícioF1ToolStripMenuItem
            // 
            this.exercícioF1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem});
            this.exercícioF1ToolStripMenuItem.Name = "exercícioF1ToolStripMenuItem";
            this.exercícioF1ToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.exercícioF1ToolStripMenuItem.Text = "Exercício &1";
            // 
            // exercícioF2ToolStripMenuItem
            // 
            this.exercícioF2ToolStripMenuItem.Name = "exercícioF2ToolStripMenuItem";
            this.exercícioF2ToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.exercícioF2ToolStripMenuItem.Text = "Exercício &2";
            this.exercícioF2ToolStripMenuItem.Click += new System.EventHandler(this.ExercícioF2ToolStripMenuItem_Click);
            // 
            // exercícioF3ToolStripMenuItem
            // 
            this.exercícioF3ToolStripMenuItem.Name = "exercícioF3ToolStripMenuItem";
            this.exercícioF3ToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.exercícioF3ToolStripMenuItem.Text = "Exercício &3";
            this.exercícioF3ToolStripMenuItem.Click += new System.EventHandler(this.ExercícioF3ToolStripMenuItem_Click);
            // 
            // exercicioF4ToolStripMenuItem
            // 
            this.exercicioF4ToolStripMenuItem.Name = "exercicioF4ToolStripMenuItem";
            this.exercicioF4ToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.exercicioF4ToolStripMenuItem.Text = "Exercício &4";
            this.exercicioF4ToolStripMenuItem.Click += new System.EventHandler(this.ExercicioF4ToolStripMenuItem_Click);
            // 
            // exercícioF5ToolStripMenuItem
            // 
            this.exercícioF5ToolStripMenuItem.Name = "exercícioF5ToolStripMenuItem";
            this.exercícioF5ToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.exercícioF5ToolStripMenuItem.Text = "Exercício &5";
            this.exercícioF5ToolStripMenuItem.Click += new System.EventHandler(this.ExercícioF5ToolStripMenuItem_Click);
            // 
            // fSairToolStripMenuItem
            // 
            this.fSairToolStripMenuItem.Name = "fSairToolStripMenuItem";
            this.fSairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.fSairToolStripMenuItem.Text = "&Sair";
            this.fSairToolStripMenuItem.Click += new System.EventHandler(this.FSairToolStripMenuItem_Click);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.copiarToolStripMenuItem.Text = "Copiar ";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.CopiarToolStripMenuItem_Click);
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.colarToolStripMenuItem.Text = "Colar";
            this.colarToolStripMenuItem.Click += new System.EventHandler(this.ColarToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorDeTextosToolStripMenuItem,
            this.calculadoraToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(158, 48);
            // 
            // editorDeTextosToolStripMenuItem
            // 
            this.editorDeTextosToolStripMenuItem.Name = "editorDeTextosToolStripMenuItem";
            this.editorDeTextosToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.editorDeTextosToolStripMenuItem.Text = "Editor de Textos";
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.calculadoraToolStripMenuItem.Text = "Calculadora";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exercícioF1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercícioF2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercícioF3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioF4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercícioF5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fSairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
    }
}

