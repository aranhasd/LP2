﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (var i=0; i<rchtxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contador++;
                }

            }
            MessageBox.Show("Quantidade de números: " +contador);
        }

        private void BtnContaLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"Quantidade de letras: {contador}");
        }

        private void BtnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posição = 0;
            int contador = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[contador]))
                {
                    posição = contador + 1;
                    break;
                }

                contador++;
            }
            MessageBox.Show("O primeiro caracter em branco está na posição: " +posição);

        }
    }
}
