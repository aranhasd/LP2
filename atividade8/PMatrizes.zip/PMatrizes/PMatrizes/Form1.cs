﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número para posição:{i + 1}");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
                auxiliar += i + "\n";
            MessageBox.Show(auxiliar);

        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string saida = "";
            double []  media = new double [20];

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite uma nota: {nota+1}");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]) || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)  
                    {
                        MessageBox.Show("Comando inválido.");
                        nota--;
                    }
                    else
                    {
                        if (nota == 2)
                        {
                            media[aluno] = notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2] / 3;
                        }
                        saida = notas[aluno, nota] + "\n" + saida;
                        

                    }
                    MessageBox.Show($"Aluno {aluno + 1}: media: {saida}");


                }

            }
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();

            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");

         
            foreach (string aluno in alunos)
            {
                MessageBox.Show($"Alunos restantes: {aluno} ");

            }
        }

       
    }
}



